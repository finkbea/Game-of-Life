Adicus Finkbeiner
CS410 Logical Programming

Compiling/Running my code:
    type "prolog" into the Terminal
    type "['logical.pl']." into the new prompt
    type "main." into the new prompt
